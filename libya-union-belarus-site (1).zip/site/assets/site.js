/* ===== إعدادات الموقع: عدّل الروابط هنا فقط ===== */
const CONFIG={
 name:"اتحاد الطلبة الليبيين في بيلاروسيا",
 repo:"USERNAME/REPO", // اسم حسابك/اسم المستودع لاستقبال طلبات التسجيل
 email:"info@example.com",
 social:[ // أشهر المنصات في ليبيا
  ["Facebook","fa-brands fa-facebook-f","#1877f2","https://facebook.com/"],
  ["WhatsApp","fa-brands fa-whatsapp","#25d366","https://wa.me/"],
  ["Telegram","fa-brands fa-telegram","#27a7e5","https://t.me/"],
  ["Instagram","fa-brands fa-instagram","#e4405f","https://instagram.com/"],
  ["TikTok","fa-brands fa-tiktok","#ff0050","https://tiktok.com/@"],
  ["YouTube","fa-brands fa-youtube","#ff0000","https://youtube.com/"],
  ["X","fa-brands fa-x-twitter","#888","https://x.com/"],
  ["Snapchat","fa-brands fa-snapchat","#fffc00","https://snapchat.com/add/"],
  ["Messenger","fa-brands fa-facebook-messenger","#0084ff","https://m.me/"],
  ["LinkedIn","fa-brands fa-linkedin-in","#0a66c2","https://linkedin.com/"]]};
const pages=[["index.html","الرئيسية"],["students.html","دليل الطلبة"],["contact.html","اتصل بنا"]];
const cur=location.pathname.split("/").pop()||"index.html";
document.getElementById("hdr").outerHTML=`<header><div class="wrap"><a class="brand" href="index.html"><img src="assets/logo.svg" alt="شعار"><span>${CONFIG.name}</span></a>
<button class="burger" aria-label="القائمة" onclick="document.querySelector('nav').classList.toggle('open')">☰</button>
<nav>${pages.map(p=>`<a href="${p[0]}" class="${p[0]==cur?'on':''}">${p[1]}</a>`).join("")}</nav></div></header>`;
document.getElementById("ftr").outerHTML=`<footer><div class="wrap"><div class="fg">
<div><h4>${CONFIG.name}</h4><p>منصة تجمع الطلبة الليبيين في بيلاروسيا وتخدمهم أكاديمياً واجتماعياً.</p>
<div class="soc">${CONFIG.social.map(s=>`<a href="${s[3]}" target="_blank" rel="noopener" title="${s[0]}" aria-label="${s[0]}" style="--c:${s[2]}"><i class="${s[1]}"></i></a>`).join("")}</div></div>
<div><h4>روابط</h4><ul><li><a href="index.html">الرئيسية</a></li><li><a href="students.html">دليل الطلبة</a></li><li><a href="contact.html">اتصل بنا</a></li></ul></div>
<div><h4>القانونية</h4><ul><li><a href="privacy.html">سياسة الخصوصية</a></li><li><a href="terms.html">شروط الاستخدام</a></li><li><a href="contact.html">الدعم</a></li></ul></div>
</div><div class="copy">© ${new Date().getFullYear()} ${CONFIG.name} — جميع الحقوق محفوظة</div></div></footer>`;
