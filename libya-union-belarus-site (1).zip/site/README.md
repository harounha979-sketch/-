# اتحاد الطلبة الليبيين في بيلاروسيا
1. ارفع كل الملفات إلى مستودع Public.  2. Settings ← Pages ← Branch main.
3. عدّل `assets/site.js` (الروابط والبريد واسم المستودع).  4. أضف الطلبة في `data/students.json`.
